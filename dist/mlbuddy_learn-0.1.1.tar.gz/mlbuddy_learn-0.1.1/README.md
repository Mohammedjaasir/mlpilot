# MLBuddy

Machine Learning automation and guidance system.

## Project Structure

- **mlbuddy/auto/**: Automated machine learning tasks
  - `data.py`: Data handling and preprocessing
  - `trainer.py`: Model training utilities
  
- **mlbuddy/guide/**: ML guidance and suggestions
  - `suggest.py`: Suggestions engine for ML workflows
  
- **mlbuddy/explain/**: Model interpretation and visualization
  - `visualizer.py`: Model visualization tools
  
- **tests/**: Test suite

## Installation

```bash
pip install -e .
```

## Development

Install development dependencies:

```bash
pip install -e ".[dev]"
```

Run tests:

```bash
pytest
```
